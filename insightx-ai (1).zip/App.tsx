
import React, { useState, useEffect } from 'react';
import { User, AppView } from './types';
import Login from './components/Login';
import ChatInterface from './components/ChatInterface';
import Profile from './components/Profile';
import LiveVoice from './components/LiveVoice';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<AppView>('chat');
  const [isInitializing, setIsInitializing] = useState(true);

  // Persistence: Load user from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('insightx_user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        console.error("Failed to parse saved user", e);
        localStorage.removeItem('insightx_user');
      }
    }
    setIsInitializing(false);
  }, []);

  const handleLogin = (email: string, displayName: string) => {
    const newUser: User = { 
      id: Math.random().toString(36).substr(2, 9),
      email, 
      displayName, 
      isLoggedIn: true,
      createdAt: new Date().toISOString()
    };
    setUser(newUser);
    // Save to localStorage so it "stays longer"
    localStorage.setItem('insightx_user', JSON.stringify(newUser));
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('chat');
    localStorage.removeItem('insightx_user');
  };

  const handleUpdateUser = (data: Partial<User>) => {
    setUser(prev => {
      if (!prev) return null;
      const updated = { ...prev, ...data };
      localStorage.setItem('insightx_user', JSON.stringify(updated));
      return updated;
    });
  };

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-blue-600/20 border-t-blue-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex flex-col md:flex-row h-screen bg-[#09090b] text-zinc-300">
      <aside className="w-full md:w-72 border-b md:border-b-0 md:border-r border-zinc-800/50 flex flex-col p-6 space-y-10 shrink-0 bg-[#0c0c0e]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-tr from-blue-600 to-indigo-700 rounded-xl flex items-center justify-center shadow-lg shadow-blue-900/40">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <span className="text-2xl font-black italic tracking-tighter text-white">insightX</span>
        </div>

        <nav className="flex-grow space-y-3">
          <button 
            onClick={() => setCurrentView('chat')}
            className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all font-bold ${currentView === 'chat' ? 'bg-blue-600/10 text-blue-400 ring-1 ring-blue-600/20' : 'text-zinc-500 hover:bg-zinc-900'}`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
            ห้องแชทหลัก
          </button>
          
          <button 
            onClick={() => setCurrentView('live_voice')}
            className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all font-bold ${currentView === 'live_voice' ? 'bg-blue-600/10 text-blue-400 ring-1 ring-blue-600/20' : 'text-zinc-500 hover:bg-zinc-900'}`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
            สนทนาเสียงสด
          </button>
          
          <button 
            onClick={() => setCurrentView('profile')}
            className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all font-bold ${currentView === 'profile' ? 'bg-blue-600/10 text-blue-400 ring-1 ring-blue-600/20' : 'text-zinc-500 hover:bg-zinc-900'}`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
            บัญชีผู้ใช้งาน
          </button>
        </nav>

        <div className="pt-8 border-t border-zinc-800/50 space-y-6">
          <div className="flex items-center gap-4 px-2">
            <div className="w-10 h-10 rounded-2xl bg-zinc-800 flex items-center justify-center text-sm font-black border border-zinc-700 text-zinc-400 overflow-hidden relative">
              {user.avatarUrl ? (
                <img src={user.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                user.displayName.charAt(0).toUpperCase()
              )}
              {/* mali.tm persistent indicator */}
              <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-[#0c0c0e] rounded-full" title="Active Persistent Session via mali.tm"></div>
            </div>
            <div className="flex-grow overflow-hidden">
              <p className="text-sm font-black text-white truncate italic">{user.displayName}</p>
              <div className="flex items-center gap-1">
                 <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest truncate">{user.email}</p>
                 <span className="text-[8px] bg-blue-900/30 text-blue-400 px-1 rounded border border-blue-800/50">mali.tm</span>
              </div>
            </div>
          </div>
          <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 px-4 py-3 text-xs font-black text-red-900/60 hover:text-red-500 transition-colors uppercase tracking-[0.2em] border border-red-900/10 rounded-xl">ออกจากระบบ</button>
        </div>
      </aside>

      <main className="flex-grow overflow-hidden relative">
        {currentView === 'chat' && <ChatInterface />}
        {currentView === 'live_voice' && <LiveVoice />}
        {currentView === 'profile' && <Profile user={user} onUpdate={handleUpdateUser} onLogout={handleLogout} />}
      </main>
    </div>
  );
};

export default App;
