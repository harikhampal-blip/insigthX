
import { GoogleGenAI, GenerateContentResponse, Modality } from "@google/genai";
import { AIMode } from "../types";

const SYSTEM_INSTRUCTION = `คุณคือ "insightX" (อินไซต์เอกซ์) ผู้ช่วย AI อัจฉริยะ 
คุณต้องแนะนำตัวเองว่าชื่อ insightX เสมอหากถูกถาม 
คุณถูกออกแบบมาเพื่อการวิเคราะห์ข้อมูลที่แม่นยำ การทำความเข้าใจรูปภาพ และการสร้างสรรค์สื่อ 
จงตอบคำถามด้วยความเป็นมืออาชีพ สุภาพ และให้ข้อมูลที่ลึกซึ้ง (Insightful) 
หากใช้โหมด ANALYTICAL ให้ใช้การคิดวิเคราะห์อย่างเป็นขั้นตอนและละเอียดที่สุด`;

export const callGemini = async (
  prompt: string,
  mode: AIMode,
  history: { role: 'user' | 'model'; parts: { text: string }[] }[] = [],
  fileData?: { data: string; mimeType: string },
  videoConfig?: { aspectRatio: '16:9' | '9:16' }
): Promise<{ text: string; sources?: any[]; imageUrl?: string; videoUrl?: string }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

  if (mode === AIMode.VIDEO_GEN) {
    if (!fileData && !prompt.trim()) {
      throw new Error("กรุณาอัปโหลดรูปภาพหรือระบุคำสั่งเพื่อสร้างวิดีโอ");
    }
    
    try {
      let videoParams: any = {
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt.trim() || 'สร้างวิดีโอที่มีความเคลื่อนไหวและองค์ประกอบที่น่าสนใจจากภาพนี้',
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: videoConfig?.aspectRatio || '16:9'
        }
      };

      if (fileData) {
        videoParams.image = {
          imageBytes: fileData.data,
          mimeType: fileData.mimeType,
        };
      }

      let operation = await ai.models.generateVideos(videoParams);

      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (!downloadLink) throw new Error("ไม่สามารถสร้างวิดีโอได้ในขณะนี้");

      const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
      if (!response.ok) throw new Error("เกิดข้อผิดพลาดในการดึงไฟล์วิดีโอ");
      
      const blob = await response.blob();
      return { 
        text: "insightX และ Veo ได้รังสรรค์วิดีโอให้คุณเรียบร้อยแล้ว", 
        videoUrl: URL.createObjectURL(blob) 
      };
    } catch (error: any) {
      if (error.message?.includes("Requested entity was not found.")) {
        throw new Error("AUTH_REQUIRED_VEO");
      }
      throw error;
    }
  }

  let modelName = 'gemini-3-flash-preview';
  let config: any = {
    systemInstruction: SYSTEM_INSTRUCTION,
    temperature: 0.7,
  };

  switch (mode) {
    case AIMode.FAST:
      modelName = 'gemini-3-flash-preview';
      break;
    case AIMode.ANALYTICAL:
      modelName = 'gemini-3-pro-preview';
      config.thinkingConfig = { thinkingBudget: 32768 };
      break;
    case AIMode.PRO:
      modelName = 'gemini-3-pro-preview';
      break;
    case AIMode.LIVE:
      modelName = 'gemini-3-flash-preview';
      config.tools = [{ googleSearch: {} }];
      break;
    case AIMode.IMAGE_EDIT:
      modelName = 'gemini-2.5-flash-image';
      break;
  }

  const parts: any[] = [{ text: prompt || "วิเคราะห์ภาพนี้ให้หน่อยครับ" }];
  if (fileData) {
    parts.unshift({
      inlineData: fileData
    });
  }

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: modelName,
      contents: [
        ...history,
        { role: 'user', parts }
      ],
      config,
    });

    let text = response.text || "";
    let imageUrl: string | undefined;

    if (mode === AIMode.IMAGE_EDIT) {
      const imagePart = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
      if (imagePart?.inlineData) {
        imageUrl = `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
      }
    }

    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title || "แหล่งข้อมูลภายนอก",
      uri: chunk.web?.uri || "#"
    }));

    return { 
      text: text || (imageUrl ? " insightX ได้แก้ไขรูปภาพให้ตามคำสั่งของคุณแล้ว" : ""), 
      sources,
      imageUrl
    };
  } catch (error: any) {
    console.error("insightX API Error:", error);
    throw error;
  }
};

/**
 * Transcribes audio using Gemini 3 Flash
 */
export const transcribeAudio = async (base64Audio: string, mimeType: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Audio, mimeType } },
        { text: "กรุณาถอดความจากเสียงนี้เป็นข้อความภาษาไทยอย่างถูกต้อง" }
      ]
    }
  });
  return response.text || "";
};

/**
 * Generates speech from text using Gemini 2.5 Flash TTS
 */
export const generateSpeech = async (text: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Say this clearly in Thai: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });
  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("Could not generate speech audio");
  return base64Audio;
};
