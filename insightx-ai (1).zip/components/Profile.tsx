
import React, { useState } from 'react';
import { User } from '../types';

interface ProfileProps {
  user: User;
  onUpdate: (data: Partial<User>) => void;
  onLogout: () => void;
}

const Profile: React.FC<ProfileProps> = ({ user, onUpdate, onLogout }) => {
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  
  // Local state for editing fields
  const [tempDisplayName, setTempDisplayName] = useState(user.displayName);
  const [tempEmail, setTempEmail] = useState(user.email);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleProfileUpdate = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e: any) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = () => {
          onUpdate({ avatarUrl: reader.result as string });
          alert("อัปเดตรูปโปรไฟล์สำเร็จ!");
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  const handleSaveGeneral = async () => {
    setIsSaving(true);
    // Simulate network delay
    await new Promise(r => setTimeout(r, 800));
    onUpdate({ displayName: tempDisplayName, email: tempEmail });
    setIsSaving(false);
    alert("บันทึกข้อมูลส่วนตัวสำเร็จ!");
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      alert("รหัสผ่านไม่ตรงกัน!");
      return;
    }
    if (newPassword.length < 6) {
      alert("รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร");
      return;
    }
    
    setIsSaving(true);
    await new Promise(r => setTimeout(r, 1000));
    // In a real app, we'd hash this. For local simulation, we just confirm.
    alert("เปลี่ยนรหัสผ่านสำเร็จ!");
    setNewPassword('');
    setConfirmPassword('');
    setShowPasswordModal(false);
    setIsSaving(false);
  };

  const confirmDeleteAccount = () => {
    alert("ลบบัญชีสำเร็จ ระบบกำลังนำคุณออก...");
    onLogout();
  };

  const hasChanges = tempDisplayName !== user.displayName || tempEmail !== user.email;

  return (
    <div className="h-full bg-[#09090b] text-zinc-200 p-8 overflow-y-auto custom-scrollbar relative">
      <div className="max-w-2xl mx-auto space-y-12">
        <header className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-black text-white italic tracking-tight">ตั้งค่าบัญชี insightX</h1>
            <p className="text-zinc-500 mt-2">จัดการข้อมูลส่วนตัว ความปลอดภัย และสิทธิพิเศษของคุณ</p>
          </div>
          <div className="bg-blue-600/10 border border-blue-500/20 px-3 py-1.5 rounded-xl flex items-center gap-2">
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
            <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest">mali.tm Active</span>
          </div>
        </header>

        <section className="space-y-8">
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-3xl font-black shadow-2xl shadow-blue-900/40 overflow-hidden relative group cursor-pointer" onClick={handleProfileUpdate}>
              {user.avatarUrl ? (
                <img src={user.avatarUrl} alt="Avatar" className="w-full h-full object-cover transition-transform group-hover:scale-110" />
              ) : (
                user.displayName.charAt(0).toUpperCase()
              )}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                 <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                {user.displayName}
                <svg className="w-5 h-5 text-blue-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.633.317 1.229.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
              </h3>
              <p className="text-zinc-500">สมาชิกตั้งแต่ {new Date(user.createdAt).toLocaleDateString('th-TH')}</p>
              <div className="flex items-center gap-2 mt-2">
                 <span className="text-[10px] bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded border border-zinc-700 font-bold uppercase tracking-wider">Session Protected</span>
                 <span className="text-[10px] bg-blue-900/20 text-blue-400 px-2 py-0.5 rounded border border-blue-800/30 font-bold uppercase tracking-wider">mali.tm Identity</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest ml-1">ชื่อที่แสดง</label>
              <input 
                type="text" 
                value={tempDisplayName}
                onChange={(e) => setTempDisplayName(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl px-5 py-4 text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest ml-1">อีเมลแอดเดรส (mali.tm Verified)</label>
              <div className="relative">
                <input 
                  type="email" 
                  value={tempEmail}
                  onChange={(e) => setTempEmail(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl px-5 py-4 text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all pr-12"
                />
                <svg className="w-5 h-5 text-blue-500 absolute right-4 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
              </div>
            </div>
          </div>

          {hasChanges && (
             <div className="animate-in fade-in slide-in-from-top-2 duration-300">
               <button 
                disabled={isSaving}
                onClick={handleSaveGeneral}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-8 py-3.5 rounded-2xl transition-all shadow-lg shadow-blue-600/20 active:scale-95 disabled:opacity-50 flex items-center gap-2"
               >
                 {isSaving && <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>}
                 บันทึกการเปลี่ยนแปลง
               </button>
             </div>
          )}

          <div className="space-y-4">
            <h4 className="text-lg font-bold text-white pt-4">ความปลอดภัยและสิทธิพิเศษ</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-2">
                <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest">สถานะเซสชัน</p>
                <p className="text-sm font-bold text-green-500 flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                  Persistent Active (mali.tm)
                </p>
                <p className="text-[10px] text-zinc-600 italic">บัญชีของคุณจะไม่หลุดออกจากระบบเมื่อปิดเบราว์เซอร์</p>
              </div>
              <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-2">
                <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest">การป้องกันข้อมูล</p>
                <p className="text-sm font-bold text-blue-400">insightX Encryption V2</p>
                <p className="text-[10px] text-zinc-600 italic">การแชทและการวิเคราะห์ของคุณถูกเข้ารหัสต้นทาง</p>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row gap-4 pt-4">
              <button 
                onClick={() => setShowPasswordModal(true)}
                className="w-full md:w-auto bg-zinc-800 hover:bg-zinc-700 text-white font-bold px-8 py-3.5 rounded-2xl transition-all"
              >
                เปลี่ยนรหัสผ่าน
              </button>
              <button 
                onClick={() => setShowDeleteModal(true)}
                className="w-full md:w-auto bg-red-900/10 hover:bg-red-900/30 text-red-500 font-bold px-8 py-3.5 rounded-2xl transition-all border border-red-900/20"
              >
                ลบบัญชีผู้ใช้งาน
              </button>
            </div>
          </div>
        </section>

        <section className="p-6 bg-blue-600/5 border border-blue-600/10 rounded-3xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
             <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
          </div>
          <h4 className="text-blue-400 font-bold flex items-center gap-2 mb-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            สิทธิประโยชน์สมาชิก insightX x mali.tm
          </h4>
          <p className="text-sm text-zinc-400 leading-relaxed max-w-lg">
            ในฐานะสมาชิก insightX คุณสามารถเข้าถึงโมเดลวิเคราะห์ข้อมูลระดับสูง (Gemini 3 Pro) 
            ระบบสืบค้นข้อมูลสด และเทคโนโลยีสร้างวิดีโอ Veo ได้อย่างไม่มีข้อจำกัด 
            พร้อมระบบยืนยันตัวตนแบบ mali.tm ที่ช่วยให้คุณใช้งานได้ยาวนานโดยไม่ต้องล็อกอินซ้ำบ่อยๆ
          </p>
        </section>
      </div>

      {/* Change Password Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowPasswordModal(false)}></div>
          <div className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-[2rem] p-8 shadow-2xl animate-in zoom-in-95 duration-200">
            <h3 className="text-2xl font-black text-white italic mb-6">เปลี่ยนรหัสผ่าน</h3>
            <form onSubmit={handleChangePassword} className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest ml-1">รหัสผ่านใหม่</label>
                <input 
                  type="password" 
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full bg-zinc-800/50 border border-zinc-700 rounded-2xl px-5 py-4 text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  placeholder="อย่างน้อย 6 ตัวอักษร"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest ml-1">ยืนยันรหัสผ่านใหม่</label>
                <input 
                  type="password" 
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full bg-zinc-800/50 border border-zinc-700 rounded-2xl px-5 py-4 text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  placeholder="ป้อนรหัสผ่านอีกครั้ง"
                />
              </div>
              
              <div className="flex flex-col gap-3 pt-4">
                <button 
                  type="submit"
                  disabled={isSaving}
                  className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 rounded-2xl transition-all shadow-lg shadow-blue-600/20 active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isSaving && <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>}
                  อัปเดตรหัสผ่าน
                </button>
                <button 
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="w-full bg-zinc-800 hover:bg-zinc-700 text-white font-bold py-4 rounded-2xl transition-all"
                >
                  ยกเลิก
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowDeleteModal(false)}></div>
          <div className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-[2rem] p-8 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-red-600/10 rounded-2xl flex items-center justify-center text-red-500 mb-6">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            
            <h3 className="text-2xl font-black text-white italic mb-3">ยืนยันการลบบัญชี?</h3>
            <p className="text-zinc-500 mb-8 leading-relaxed">
              การดำเนินการนี้ไม่สามารถย้อนกลับได้ ข้อมูลการแชท รูปภาพ และการตั้งค่าทั้งหมดของคุณจะถูกลบอย่างถาวรจากระบบ insightX
            </p>
            
            <div className="flex flex-col gap-3">
              <button 
                onClick={confirmDeleteAccount}
                className="w-full bg-red-600 hover:bg-red-500 text-white font-bold py-4 rounded-2xl transition-all shadow-lg shadow-red-600/20 active:scale-[0.98]"
              >
                ยืนยันลบบัญชี
              </button>
              <button 
                onClick={() => setShowDeleteModal(false)}
                className="w-full bg-zinc-800 hover:bg-zinc-700 text-white font-bold py-4 rounded-2xl transition-all"
              >
                ยกเลิก
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Profile;
