
import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';

const LiveVoice: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [status, setStatus] = useState('พร้อมสำหรับการสนทนา');
  const [transcriptions, setTranscriptions] = useState<{role: 'user' | 'model', text: string}[]>([]);
  const currentInputTransRef = useRef('');
  const currentOutputTransRef = useRef('');
  
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext) => {
    const dataInt16 = new Int16Array(data.buffer);
    const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
    return buffer;
  };

  const startSession = async () => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setStatus('กำลังเชื่อมต่อ...');
            setIsActive(true);
            const inputContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            const source = inputContext.createMediaStreamSource(stream);
            const processor = inputContext.createScriptProcessor(4096, 1, 1);
            processor.onaudioprocess = (e) => {
              const input = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(input.length);
              for (let i = 0; i < input.length; i++) int16[i] = input[i] * 32768;
              const base64 = encode(new Uint8Array(int16.buffer));
              sessionPromise.then(s => s.sendRealtimeInput({ media: { data: base64, mimeType: 'audio/pcm;rate=16000' } }));
            };
            source.connect(processor);
            processor.connect(inputContext.destination);
          },
          onmessage: async (msg: any) => {
            // Handle Transcriptions
            if (msg.serverContent?.inputTranscription) {
              currentInputTransRef.current += msg.serverContent.inputTranscription.text;
            } else if (msg.serverContent?.outputTranscription) {
              currentOutputTransRef.current += msg.serverContent.outputTranscription.text;
            }

            if (msg.serverContent?.turnComplete) {
              const uText = currentInputTransRef.current;
              const mText = currentOutputTransRef.current;
              setTranscriptions(prev => [...prev, {role: 'user', text: uText}, {role: 'model', text: mText}]);
              currentInputTransRef.current = '';
              currentOutputTransRef.current = '';
            }

            // Handle Audio
            const audioData = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && audioContextRef.current) {
              const buffer = await decodeAudioData(decode(audioData), audioContextRef.current);
              const source = audioContextRef.current.createBufferSource();
              source.buffer = buffer;
              source.connect(audioContextRef.current.destination);
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, audioContextRef.current.currentTime);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
              setStatus('insightX กำลังพูด...');
            }
            if (msg.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setStatus('ถูกขัดจังหวะ...');
            }
          },
          onclose: () => {
            setIsActive(false);
            setStatus('สิ้นสุดการสนทนา');
          },
          onerror: (e) => {
            console.error(e);
            setStatus('เกิดข้อผิดพลาด');
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          systemInstruction: 'คุณคือ insightX ผู้ช่วย AI เสียงสดที่ฉลาดและเป็นกันเอง ตอบเป็นภาษาไทยเสมอ กระชับและชัดเจน'
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      setStatus('เกิดข้อผิดพลาดในการเชื่อมต่อ');
    }
  };

  const stopSession = () => {
    if (sessionRef.current) sessionRef.current.close();
    setIsActive(false);
  };

  return (
    <div className="h-full flex flex-col items-center bg-[#09090b] text-white p-6 overflow-y-auto custom-scrollbar">
      <div className="w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-[2.5rem] p-8 flex flex-col items-center space-y-8 shadow-2xl mt-10">
        <div className={`w-32 h-32 rounded-full flex items-center justify-center transition-all duration-700 ${isActive ? 'bg-blue-600 shadow-[0_0_50px_rgba(37,99,235,0.4)] animate-pulse' : 'bg-zinc-800'}`}>
          <svg className={`w-16 h-16 ${isActive ? 'text-white' : 'text-zinc-600'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
          </svg>
        </div>
        
        <div className="text-center">
          <h2 className="text-2xl font-black italic mb-2 tracking-tight">insightX Live Voice</h2>
          <p className={`text-sm font-bold uppercase tracking-widest ${isActive ? 'text-blue-400 animate-pulse' : 'text-zinc-500'}`}>{status}</p>
        </div>

        {isActive && transcriptions.length > 0 && (
          <div className="w-full max-h-64 overflow-y-auto space-y-4 px-2 custom-scrollbar border-t border-zinc-800 pt-6">
            {transcriptions.slice(-6).map((t, i) => (
              <div key={i} className={`flex flex-col ${t.role === 'user' ? 'items-end' : 'items-start'}`}>
                <span className="text-[10px] font-bold text-zinc-600 uppercase mb-1">{t.role === 'user' ? 'You' : 'insightX'}</span>
                <div className={`px-4 py-2 rounded-2xl text-sm ${t.role === 'user' ? 'bg-blue-600 text-white' : 'bg-zinc-800 text-zinc-300'}`}>
                  {t.text}
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="w-full pt-4">
          {isActive ? (
            <button onClick={stopSession} className="w-full bg-red-600/10 text-red-500 hover:bg-red-600/20 py-4 rounded-2xl font-bold transition-all border border-red-600/20 shadow-xl">
              วางสาย (Stop Session)
            </button>
          ) : (
            <button onClick={startSession} className="w-full bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-2xl font-bold transition-all shadow-xl shadow-blue-600/20">
              เริ่มการสนทนาเสียงสด
            </button>
          )}
        </div>
        
        <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-[0.2em] text-center max-w-xs">
          คุยกับ insightX ได้ทันทีด้วยเทคโนโลยี Native Audio ความหน่วงต่ำ
        </p>
      </div>
    </div>
  );
};

export default LiveVoice;
