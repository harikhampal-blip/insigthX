
import React, { useState } from 'react';

interface LoginProps {
  onLogin: (email: string, name: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (email && password) {
      if (isRegistering) {
        alert(`ยินดีต้อนรับคุณ ${displayName || email}! บัญชีของคุณถูกผูกกับระบบ mali.tm เพื่อการเข้าใช้งานที่ยาวนาน (Persistent Identity) เรียบร้อยแล้ว`);
      }
      onLogin(email, displayName || email.split('@')[0]);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#09090b] px-4 relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/5 blur-[120px] rounded-full"></div>
      
      <div className="w-full max-w-md space-y-8 bg-zinc-900/40 backdrop-blur-2xl p-8 rounded-[2rem] border border-zinc-800/50 relative z-10 shadow-2xl">
        <div className="text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl mx-auto flex items-center justify-center shadow-2xl shadow-blue-900/40 mb-6 rotate-3 hover:rotate-0 transition-transform duration-500">
            <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <h2 className="text-4xl font-black tracking-tight text-white italic">insightX</h2>
          <p className="mt-3 text-zinc-400 font-medium italic flex items-center justify-center gap-2">
            The Future of Deep Analytics 
            <span className="text-[10px] bg-blue-600/20 text-blue-400 px-2 py-0.5 rounded-full border border-blue-500/20 not-italic">Powered by mali.tm</span>
          </p>
        </div>

        <form className="mt-8 space-y-4" onSubmit={handleSubmit}>
          {isRegistering && (
            <div className="animate-in fade-in slide-in-from-top-2 duration-300">
              <label className="block text-sm font-medium text-zinc-400 mb-1.5 ml-1">ชื่อที่ใช้แสดง</label>
              <input
                type="text"
                required
                className="w-full bg-zinc-800/50 border border-zinc-700 text-white px-4 py-3.5 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder:text-zinc-600"
                placeholder="สมชาย ใจดี"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
              />
            </div>
          )}
          
          <div>
            <div className="flex justify-between items-center mb-1.5 ml-1">
              <label className="block text-sm font-medium text-zinc-400">อีเมล</label>
              <span className="text-[10px] text-zinc-600 font-bold uppercase tracking-wider">Verified by mali.tm</span>
            </div>
            <input
              type="email"
              required
              className="w-full bg-zinc-800/50 border border-zinc-700 text-white px-4 py-3.5 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder:text-zinc-600"
              placeholder="example@insightx.ai"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-400 mb-1.5 ml-1">รหัสผ่าน</label>
            <input
              type="password"
              required
              className="w-full bg-zinc-800/50 border border-zinc-700 text-white px-4 py-3.5 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder:text-zinc-600"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 rounded-2xl transition-all shadow-xl shadow-blue-600/20 active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : (
              isRegistering ? 'สร้างบัญชี insightX' : 'เข้าสู่ระบบ'
            )}
          </button>
        </form>

        <div className="pt-4 border-t border-zinc-800/50">
          <p className="text-center text-xs text-zinc-600 mb-4">
            อีเมลของคุณจะคงอยู่ถาวรด้วยระบบ mali.tm Identity Persistence
          </p>
          <p className="text-center text-sm text-zinc-500">
            {isRegistering ? 'มีบัญชีอยู่แล้ว?' : 'ยังไม่มีบัญชี?'} {' '}
            <button 
              onClick={() => setIsRegistering(!isRegistering)}
              className="text-blue-500 hover:text-blue-400 font-bold underline underline-offset-4 decoration-blue-500/30 transition-colors"
            >
              {isRegistering ? 'เข้าสู่ระบบที่นี่' : 'สมัครสมาชิกฟรี'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
