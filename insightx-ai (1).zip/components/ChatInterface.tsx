
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { AIMode, Message } from '../types';
import { callGemini, transcribeAudio, generateSpeech } from '../services/geminiService';

const MODE_CONFIG = {
  [AIMode.FAST]: { label: 'รวดเร็ว', icon: '⚡', color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
  [AIMode.PRO]: { label: 'โปรแชท', icon: '💎', color: 'text-indigo-400', bg: 'bg-indigo-400/10' },
  [AIMode.ANALYTICAL]: { label: 'คิดวิเคราะห์', icon: '🧠', color: 'text-blue-400', bg: 'bg-blue-400/10' },
  [AIMode.LIVE]: { label: 'สืบค้นสด', icon: '🌐', color: 'text-emerald-400', bg: 'bg-emerald-400/10' },
  [AIMode.IMAGE_EDIT]: { label: 'แก้ไขภาพ', icon: '🎨', color: 'text-pink-400', bg: 'bg-pink-400/10' },
  [AIMode.VIDEO_GEN]: { label: 'สร้างวิดีโอ', icon: '🎬', color: 'text-purple-400', bg: 'bg-purple-400/10' },
};

// Audio Decoding Utilities
const decodeBase64 = (base64: string) => {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};

const decodePCMToBuffer = async (
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1
): Promise<AudioBuffer> => {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
};

const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [mode, setMode] = useState<AIMode>(AIMode.FAST);
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [autoSpeech, setAutoSpeech] = useState(false);
  const [selectedImage, setSelectedImage] = useState<{ data: string; mimeType: string } | null>(null);
  const [videoAspectRatio, setVideoAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [thinkingMessage, setThinkingMessage] = useState<string>('');
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [showPwaHint, setShowPwaHint] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [messages, isLoading, thinkingMessage]);

  useEffect(() => {
    // Show PWA hint after a delay
    const timer = setTimeout(() => {
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
      if (!isStandalone) setShowPwaHint(true);
    }, 5000);
    return () => clearTimeout(timer);
  }, []);

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert("กรุณาอัปโหลดไฟล์รูปภาพเท่านั้น");
      return;
    }
    setIsProcessingImage(true);
    const reader = new FileReader();
    reader.onloadend = () => {
      setSelectedImage({
        data: (reader.result as string).split(',')[1],
        mimeType: file.type
      });
      setIsProcessingImage(false);
    };
    reader.onerror = () => {
      alert("เกิดข้อผิดพลาดในการอ่านไฟล์");
      setIsProcessingImage(false);
    };
    reader.readAsDataURL(file);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault(); e.stopPropagation(); setIsDragging(true);
  }, []);

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault(); e.stopPropagation(); setIsDragging(false);
  }, []);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); e.stopPropagation(); setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  }, []);

  const toggleRecording = async () => {
    if (isRecording) {
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorderRef.current = mediaRecorder;
        audioChunksRef.current = [];

        mediaRecorder.ondataavailable = (event) => {
          audioChunksRef.current.push(event.data);
        };

        mediaRecorder.onstop = async () => {
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          const reader = new FileReader();
          reader.onloadend = async () => {
            const base64Audio = (reader.result as string).split(',')[1];
            setIsLoading(true);
            setThinkingMessage('กำลังแปลงเสียงเป็นข้อความ...');
            try {
              const text = await transcribeAudio(base64Audio, 'audio/webm');
              setInput(text);
            } catch (err) {
              console.error(err);
              alert("ไม่สามารถถอดความเสียงได้");
            } finally {
              setIsLoading(false);
              setThinkingMessage('');
            }
          };
          reader.readAsDataURL(audioBlob);
          stream.getTracks().forEach(t => t.stop());
        };

        mediaRecorder.start();
        setIsRecording(true);
      } catch (err) {
        console.error(err);
        alert("ไม่สามารถเข้าถึงไมโครโฟนได้");
      }
    }
  };

  const playMessageAudio = async (msg: Message) => {
    if (playingAudioId === msg.id) return;
    setPlayingAudioId(msg.id);
    
    try {
      const base64 = await generateSpeech(msg.content);
      
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      
      const audioCtx = audioContextRef.current;
      const bytes = decodeBase64(base64);
      const buffer = await decodePCMToBuffer(bytes, audioCtx, 24000, 1);
      
      const source = audioCtx.createBufferSource();
      source.buffer = buffer;
      source.connect(audioCtx.destination);
      source.onended = () => setPlayingAudioId(null);
      source.start();
    } catch (err) {
      console.error("Speech playback error:", err);
      setPlayingAudioId(null);
    }
  };

  const handleSend = async () => {
    if (!input.trim() && !selectedImage || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now(),
      mode,
      imageUrl: selectedImage ? `data:${selectedImage.mimeType};base64,${selectedImage.data}` : undefined
    };

    setMessages(prev => [...prev, userMsg]);
    const currentInput = input;
    const currentImage = selectedImage;
    const currentAspectRatio = videoAspectRatio;
    
    setInput('');
    setSelectedImage(null);
    setIsLoading(true);

    let progressMsg = 'insightX กำลังประมวลผล...';
    if (mode === AIMode.VIDEO_GEN) progressMsg = 'insightX กำลังรังสรรค์วิดีโอ...';
    if (mode === AIMode.ANALYTICAL) progressMsg = 'insightX กำลังใช้โหมดคิดวิเคราะห์...';
    setThinkingMessage(progressMsg);

    try {
      const history = messages.slice(-10).map(m => ({
        role: (m.role === 'user' ? 'user' : 'model') as 'user' | 'model',
        parts: [{ text: m.content }]
      }));

      const response = await callGemini(
        currentInput, 
        mode, 
        history, 
        currentImage || undefined,
        { aspectRatio: currentAspectRatio }
      );

      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.text,
        timestamp: Date.now(),
        sources: response.sources,
        mode: mode,
        imageUrl: response.imageUrl,
        videoUrl: response.videoUrl
      };

      setMessages(prev => [...prev, assistantMsg]);
      
      if (autoSpeech && assistantMsg.content) {
        playMessageAudio(assistantMsg);
      }
    } catch (error: any) {
       setMessages(prev => [...prev, {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: `ขออภัยครับ เกิดข้อผิดพลาด: ${error.message || 'กรุณาลองใหม่'}`,
          timestamp: Date.now()
        }]);
    } finally {
      setIsLoading(false);
      setThinkingMessage('');
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#09090b] text-zinc-200 relative" onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop}>
      {isDragging && (
        <div className="absolute inset-0 z-50 bg-blue-600/20 backdrop-blur-sm flex items-center justify-center pointer-events-none transition-all">
          <div className="w-11/12 h-5/6 border-4 border-dashed border-blue-500/50 rounded-[3rem] flex flex-col items-center justify-center gap-6 animate-in fade-in zoom-in">
            <div className="w-24 h-24 bg-blue-600 rounded-full flex items-center justify-center shadow-2xl shadow-blue-500/40">
              <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
            </div>
            <p className="text-2xl font-black italic text-white tracking-tight text-center px-6">วางรูปภาพที่นี่เพื่อเริ่มการวิเคราะห์อัจฉริยะ</p>
          </div>
        </div>
      )}

      {showPwaHint && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-40 w-11/12 max-w-sm animate-in slide-in-from-top-4 duration-700">
           <div className="bg-blue-600 text-white p-4 rounded-2xl shadow-2xl border border-blue-400/30 flex items-center gap-4">
             <div className="bg-white/20 p-2 rounded-xl">
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
             </div>
             <div className="flex-grow">
                <p className="text-xs font-black uppercase tracking-widest mb-0.5">ติดตั้ง insightX</p>
                <p className="text-[10px] opacity-80">เพิ่มลงในหน้าจอหลักเพื่อใช้งานแบบแอปพลิเคชัน</p>
             </div>
             <button onClick={() => setShowPwaHint(false)} className="p-1 hover:bg-white/10 rounded-lg transition-colors">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
             </button>
           </div>
        </div>
      )}

      <div className="p-4 border-b border-zinc-800/50 flex items-center justify-center gap-2 flex-wrap bg-[#09090b]/80 backdrop-blur-md sticky top-0 z-20">
        {(Object.entries(MODE_CONFIG) as [AIMode, typeof MODE_CONFIG[AIMode]][]).map(([key, config]) => (
          <button key={key} onClick={() => setMode(key)} className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all ${mode === key ? `${config.bg} ${config.color} ring-1 ring-zinc-700 font-bold shadow-lg` : 'hover:bg-zinc-800 text-zinc-500'}`}>
            <span>{config.icon}</span>
            <span className="text-sm">{config.label}</span>
          </button>
        ))}
      </div>

      <div ref={scrollRef} className="flex-grow overflow-y-auto px-4 py-8 space-y-8 max-w-4xl mx-auto w-full custom-scrollbar">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-[60vh] text-center space-y-4">
            <div className="w-24 h-24 bg-zinc-900 rounded-[2rem] flex items-center justify-center mb-4 border border-zinc-800/50 shadow-inner relative group">
               <div className="absolute inset-0 bg-blue-600/5 rounded-[2rem] group-hover:bg-blue-600/10 transition-colors"></div>
               <svg className="w-12 h-12 text-zinc-700 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
            </div>
            <h3 className="text-4xl font-black italic text-white tracking-tight">insightX</h3>
            <p className="text-zinc-500 max-w-sm italic">Intelligence for complex analysis, visual arts, and lightning-fast chat.</p>
          </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-[1.8rem] px-6 py-4 shadow-2xl relative transition-all ${msg.role === 'user' ? 'bg-blue-600 text-white shadow-blue-900/10' : 'bg-zinc-900 border border-zinc-800 hover:border-zinc-700'}`}>
              {msg.imageUrl && (
                <div className="mb-4"><img src={msg.imageUrl} alt="Uploaded" className="rounded-2xl max-h-80 object-cover w-full border border-zinc-800 shadow-lg" /></div>
              )}
              {msg.videoUrl && (
                <div className="mb-4"><video src={msg.videoUrl} controls className="rounded-2xl max-h-80 w-full border border-zinc-800 shadow-xl bg-black" /></div>
              )}
              <div className="whitespace-pre-wrap leading-relaxed text-[15px] font-medium pr-10">
                {msg.content}
              </div>
              {msg.role === 'assistant' && (
                <div className="absolute top-4 right-4 flex gap-2">
                   {playingAudioId === msg.id && (
                     <div className="flex gap-0.5 items-end h-4 mr-1">
                        <div className="w-0.5 bg-blue-500 animate-[bar-grow_0.5s_ease-in-out_infinite_0s]"></div>
                        <div className="w-0.5 bg-blue-500 animate-[bar-grow_0.5s_ease-in-out_infinite_0.1s]"></div>
                        <div className="w-0.5 bg-blue-500 animate-[bar-grow_0.5s_ease-in-out_infinite_0.2s]"></div>
                     </div>
                   )}
                   <button 
                    onClick={() => playMessageAudio(msg)} 
                    title="อ่านข้อความนี้"
                    className={`p-2 rounded-xl transition-all ${playingAudioId === msg.id ? 'bg-blue-600 text-white ring-2 ring-blue-500/50 shadow-blue-500/20' : 'bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700'}`}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                  </button>
                </div>
              )}
              {msg.sources && msg.sources.length > 0 && (
                <div className="mt-5 pt-4 border-t border-zinc-800">
                  <span className="text-[10px] font-bold text-zinc-500 mb-3 block uppercase tracking-widest">Verified Sources</span>
                  <div className="flex flex-wrap gap-2">
                    {msg.sources.map((s, i) => (
                      <a key={i} href={s.uri} target="_blank" rel="noopener noreferrer" className="text-[11px] bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 px-3 py-1.5 rounded-xl text-blue-400 transition-colors truncate max-w-[200px]">{s.title}</a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start animate-in fade-in slide-in-from-left-4 duration-500">
            <div className="bg-zinc-900/60 backdrop-blur-xl border border-zinc-800/80 rounded-[2rem] px-8 py-6 flex flex-col gap-4 shadow-2xl min-w-[280px]">
              <div className="flex items-center gap-5">
                <div className="relative">
                  <div className="absolute inset-0 bg-blue-500/30 rounded-full blur-md animate-pulse"></div>
                  <div className="relative w-4 h-4 bg-gradient-to-tr from-blue-600 to-indigo-400 rounded-full shadow-[0_0_15px_rgba(59,130,246,0.6)] animate-[orb-float_2s_ease-in-out_infinite]"><div className="absolute inset-0 bg-white/20 rounded-full blur-[2px]"></div></div>
                </div>
                <div className="flex flex-col">
                  <span className="text-xs font-black text-zinc-200 uppercase tracking-[0.2em] animate-pulse">{thinkingMessage}</span>
                  <div className="flex gap-1 mt-1">
                    <div className="w-1 h-1 bg-blue-500/50 rounded-full animate-[loading-dots_1.4s_infinite_0s]"></div>
                    <div className="w-1 h-1 bg-blue-500/50 rounded-full animate-[loading-dots_1.4s_infinite_0.2s]"></div>
                    <div className="w-1 h-1 bg-blue-500/50 rounded-full animate-[loading-dots_1.4s_infinite_0.4s]"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-[#09090b]/80 border-t border-zinc-800 backdrop-blur-md">
        <div className="max-w-4xl mx-auto space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {isProcessingImage && (
                <div className="flex items-center gap-3 bg-zinc-900/50 p-3 rounded-2xl border border-zinc-800 animate-pulse">
                   <div className="w-8 h-8 rounded-lg bg-zinc-800 animate-pulse"></div>
                   <span className="text-xs font-bold text-zinc-500 uppercase tracking-widest">กำลังอ่านข้อมูล...</span>
                </div>
              )}
              {selectedImage && !isProcessingImage && (
                <div className="flex items-center gap-4 animate-in slide-in-from-bottom-2 duration-300 bg-zinc-900 p-2.5 rounded-[1.5rem] border-2 border-blue-600/30 w-fit group shadow-xl">
                  <div className="relative">
                    <img src={`data:${selectedImage.mimeType};base64,${selectedImage.data}`} className="h-20 w-20 rounded-xl object-cover border border-zinc-700/50" />
                    <button onClick={() => setSelectedImage(null)} className="absolute -top-3 -right-3 bg-red-600 text-white rounded-full p-1.5 shadow-xl hover:bg-red-500 transition-all hover:rotate-90 active:scale-90">
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                  </div>
                  <div className="pr-4 hidden sm:block">
                    <p className="text-[10px] font-black text-blue-400 uppercase tracking-[0.2em] mb-1">Image Ready</p>
                    <p className="text-[11px] text-zinc-500 font-medium truncate max-w-[100px]">{selectedImage.mimeType.split('/')[1].toUpperCase()} Format</p>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="relative flex items-center gap-3">
            <button onClick={() => fileInputRef.current?.click()} className="p-4 bg-zinc-900 border border-zinc-800 rounded-[1.5rem] text-zinc-500 hover:text-white hover:bg-zinc-800 transition-all shadow-xl active:scale-95 group relative" title="อัปโหลดรูปภาพ">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
            </button>
            <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" />
            
            <div className="relative flex-grow">
              <textarea
                rows={1}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                placeholder={mode === AIMode.VIDEO_GEN ? "บรรยายสไตล์แอนิเมชัน อารมณ์ และองค์ประกอบ..." : "สอบถาม insightX หรือกดไมโครโฟนเพื่อพูด?"}
                className="w-full bg-zinc-900 border border-zinc-800 text-white px-6 py-5 rounded-[1.8rem] pr-44 focus:ring-2 focus:ring-blue-600/30 outline-none resize-none shadow-2xl placeholder:text-zinc-600 font-medium transition-all"
              />
              <div className="absolute right-2.5 bottom-2.5 flex gap-2">
                <button
                  onClick={() => setAutoSpeech(!autoSpeech)}
                  title={autoSpeech ? "ปิดโหมดอ่านออกเสียงอัตโนมัติ" : "เปิดโหมดอ่านออกเสียงอัตโนมัติ"}
                  className={`p-3 rounded-2xl transition-all shadow-lg relative group ${autoSpeech ? 'bg-blue-600 text-white shadow-blue-500/20 ring-2 ring-blue-500/50' : 'bg-zinc-800 text-zinc-400 hover:text-white active:scale-90 hover:bg-zinc-700'}`}
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5L6 9H2v6h4l5 4V5zM19.07 4.93a10 10 0 010 14.14M15.54 8.46a5 5 0 010 7.07" /></svg>
                  <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 px-2 py-1 bg-zinc-800 text-[10px] text-zinc-300 rounded border border-zinc-700 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                    {autoSpeech ? "Speech: ON" : "Speech: OFF"}
                  </span>
                </button>
                <button
                  onClick={toggleRecording}
                  title="พูดเพื่อถอดความ (Speech-to-Text)"
                  className={`p-3 rounded-2xl transition-all shadow-lg ${isRecording ? 'bg-red-600 text-white animate-pulse shadow-red-500/40' : 'bg-zinc-800 text-zinc-400 hover:text-white active:scale-90 hover:bg-zinc-700'}`}
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
                </button>
                <button
                  onClick={handleSend}
                  disabled={(!input.trim() && !selectedImage) || isLoading}
                  className={`p-3 rounded-2xl transition-all shadow-lg ${input.trim() || selectedImage ? 'bg-blue-600 text-white hover:bg-blue-500 active:scale-90 shadow-blue-500/30' : 'bg-zinc-800 text-zinc-600 cursor-not-allowed'}`}
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                </button>
              </div>
            </div>
          </div>
          <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-[0.2em] text-center">
            {isDragging ? "ปล่อยเมาส์เพื่อส่งรูปภาพให้ insightX" : "ลากรูปภาพมาที่นี่ หรือคลิกเพื่อส่งไฟล์"}
          </p>
        </div>
      </div>
      <style>{`
        @keyframes orb-float { 0%, 100% { transform: translateY(0); scale: 1; } 50% { transform: translateY(-2px); scale: 1.1; } }
        @keyframes loading-dots { 0%, 100% { opacity: 0.3; transform: scale(0.8); } 50% { opacity: 1; transform: scale(1.2); } }
        @keyframes bar-grow { 0%, 100% { height: 4px; } 50% { height: 12px; } }
        .custom-scrollbar::-webkit-scrollbar { width: 5px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #27272a; border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default ChatInterface;
