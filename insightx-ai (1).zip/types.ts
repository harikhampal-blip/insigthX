
export enum AIMode {
  FAST = 'FAST',
  ANALYTICAL = 'ANALYTICAL',
  PRO = 'PRO',
  LIVE = 'LIVE',
  IMAGE_EDIT = 'IMAGE_EDIT',
  VIDEO_GEN = 'VIDEO_GEN'
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  mode?: AIMode;
  sources?: Array<{ title: string; uri: string }>;
  thinking?: string;
  imageUrl?: string;
  videoUrl?: string;
  isThinking?: boolean;
}

export interface User {
  id: string;
  email: string;
  displayName: string;
  isLoggedIn: boolean;
  avatarUrl?: string;
  createdAt: string;
}

export type AppView = 'chat' | 'profile' | 'live_voice';
